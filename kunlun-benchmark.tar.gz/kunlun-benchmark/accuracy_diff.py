import argparse
import difflib
import json
import os

import numpy as np
from loguru import logger


headers = ["Average", "Minimum", "Maximum", "Median", "P30", "P60", "P90"]


def calculate_statistics(data):
    # 排序数据（某些计算需要排序）
    data = [abs(d) for d in data]
    # 平均值
    mean_value = round(np.mean(data), 4)

    # 最小值
    min_value = round(np.min(data), 4)

    # 最大值
    max_value = round(np.max(data), 4)

    # 中位数
    median_value =  round(np.median(data), 4)

    # P50（与中位数相同）
    p30_value = round(np.percentile(data, 30), 4)

    # P90
    p60_value = round(np.percentile(data, 60), 4)

    # P99
    p90_value = round(np.percentile(data, 90), 4)
    return mean_value, min_value, max_value, median_value, p30_value, p60_value, p90_value

def diff(data1, data2, arg):
    tokenizer = None
    if os.path.exists(arg.bert_model):
        from sentence_transformers import SentenceTransformer
        tokenizer = SentenceTransformer(arg.bert_model)
    else:
        logger.warning(f"bert_model: {arg.bert_model} not exists")
    comms = []
    for d1 in data1:
        for d2 in data2:
            if d1["prompt"] == d2["prompt"]:
                comms.append({
                    "prompt": d1["prompt"],
                    "answer1": d1["answer"],
                    "answer2": d2["answer"],
                })
                break
    html_diff = difflib.HtmlDiff()

    # 初始化 HTML 内容
    html_content = ("""<html><head><meta charset='utf-8'><title>Unified Diff Report</title>
            <style>
            /* 表格样式 */
            table {
                width: 80%;
                margin: 20px auto;
                border-collapse: collapse;
                font-family: Arial, sans-serif;
                text-align: center;
            }
            /* 表头样式 */
            th {
                background-color: #4CAF50;
                color: white;
                padding: 10px;
                font-size: 16px;
            }
            /* 表格单元格样式 */
            td {
                border: 1px solid #ddd;
                padding: 8px;
                font-size: 14px;
            }
            /* 偶数行背景色 */
            tr:nth-child(even) {
                background-color: #f9f9f9;
            }
            /* 鼠标悬停效果 */
            tr:hover {
                background-color: #f1f1f1;
            }
            /* 标题样式 */
            h1 {
                text-align: center;
                color: #333;
            }
            </style>
                    </head><body>\n""")
    html_content += "<h1>Unified Sentence Comparison Report</h1>\n"
    similarities = []
    cnt = "<h2>Detailed data</h2>\n"
    # 遍历每组句子并生成差异报告
    for s in comms:
        prompt = s["prompt"]
        a1 = s["answer1"]
        a2 = s["answer2"]
        cnt += f"<h3>Comparison Prompt: {prompt}</h3>\n"
        if tokenizer:
            from sentence_transformers import util
            a1_emb = tokenizer.encode(a1)
            a2_emb = tokenizer.encode(a2)
            similarity = abs(round(util.cos_sim(a1_emb, a2_emb)[0][0].item(), 4))
            similarities.append(similarity)
            cnt += f"<p><strong>Similarity:</strong> {similarity}</p>\n"
        a1 = a1.replace("\n", "\\n")
        a2 = a2.replace("\n", "\\n")
        cnt += f"""<p><strong>Sentence {arg.file1}:</strong> {a1}</p>\n"""
        cnt += f"<p><strong>Sentence {arg.file2}:</strong> {a2}</p>\n"

        # 生成差异表格
        diff_table = html_diff.make_table(a1.split(), a2.split(),fromdesc=arg.file1,todesc=arg.file2, context=True, numlines=1)
        cnt += diff_table + "\n"

    table = "<h2>Statistics</h2>\n<table><thead><tr>"
    for header in headers:
        table += f"<th>{header}</th>"
    table += "</tr></thead><tbody><tr>"
    for cell in calculate_statistics(similarities):
        table += f"<td>{cell}</td>"
    table += "</tr>"

    # 结束 HTML 表格
    table += "</tbody></table>"

    # 结束 HTML 内容
    html_content += table
    html_content += cnt + "</body></html>"

    # 将结果保存到文件
    output_file = "unified_diff_report.html"
    with open(output_file, "w", encoding="utf-8") as f:
        f.write(html_content)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()

    parser.add_argument("--file1", "-f1", type=str, required=True)
    parser.add_argument("--file2", "-f2", type=str, required=True)
    # use bert model to calculate similarity
    # Recommend
    # https://www.modelscope.cn/models/sentence-transformers/all-MiniLM-L12-v2
    parser.add_argument("--bert_model", type=str, default="/fast_vcns_root/model/all-MiniLM-L12-v2/")
    args = parser.parse_args()
    with open(args.file1) as f:
        f1_data = json.load(f)
    with open(args.file2) as f:
        f2_data = json.load(f)
    diff(f1_data, f2_data, args)
